# Weapons_damage_fivem
Simple script that removes pistol-whipping, melee damage and nightstick damage.
If you wish to add more weapons to the script, it is very easy to do so, just follow the examples, but, if you want to add more than 3, i recommend you to create a dictionary inside it.
This is my first public release, if you have any questions or ideas, let me know.



Simples script que remove dano de coronhada, socos e cassetete.
Se caso quiser adicionar mais armas ao script, é muito fácil o fazer, só seguir os exemplos, mas, caso queira adicionar mais de 3 armas, recomendo que crie um dicionário.
Esse é meu primeiro release público, se tiver alguma dúvida ou ideia, me avise.
